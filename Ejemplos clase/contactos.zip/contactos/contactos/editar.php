<?php 

	$servidor = 'localhost';
		$usuario = 'root';
		$pass = '';
		$bd = 'contactos';

	$id_contacto = $_GET['id'];
	$con = new mysqli($servidor, $usuario, $pass, $bd);

	$query = "SELECT * FROM informacion where id_contacto = '$id_contacto'";
	$resultado = mysqli_query($con,$query);
	while($fila = mysqli_fetch_array($resultado))
	{
		$titulo = $fila[1];
		$nombre = $fila[2];
		$apellido = $fila[3];
		$telefono = $fila[4];
		$tipo_telefono = $fila[5];
		$correo = $fila[6];
		$direccion = $fila[7];
	}

		//print_r("hola guarde");
	if(isset($_POST["registrar"]))
	{
		///print_r("hola");

		$con = new mysqli($servidor, $usuario, $pass, $bd);

		if ($con->connect_errno) 
		{
			echo "Error al conectarse {$con->connect_errno}";
			die();
		}

		$titulo = $_POST["titulo"];
		$nombre = $_POST["nombre"];
		$apellido = $_POST["apellido"];
		$telefono = $_POST["telefono"];
		$tipoTel = $_POST["tipo_telefono"];
		$correo = $_POST["correo"];
		$direccion = $_POST["direccion"];

		$query = "UPDATE informacion SET titulo = '$titulo', nombre='$nombre', apellido = '$apellido', telefono = '$telefono', tipoTel = '$tipoTel', correo = '$correo', direccion = '$direccion' WHERE id_contacto = '$id_contacto' ";

		$resultados = $con->query($query);


	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>CONTACTOS FORMULARIO</title>
</head>
<style type="text/css">
	
	.form
	{
		font-family: Arial;
		font-size: 1em;

	}

</style>
<body>

	<center>
		<form method="POST" class="form" id="form" action="contactos1.php">
			<select name="titulo">
			<option value="" <?php if(!($titulo)) echo "selected = 'selected'"; ?>>--</option>
			<option value="ingeniero" <?php if($titulo == "ingeniero") echo "selected = 'selected'"; ?><?php if(!($titulo)) echo "selected = 'selected'"; ?>>Ingeniero</option>
			<option value="licensiado" <?php if($titulo == "licensiado") echo "selected = 'selected'";?>>Licensiado</option>
			<option value="maestro" <?php if($titulo == "maestro") echo "selected = 'selected'"; ?>>Maestro</option>
			<option value="doctor" <?php if($titulo == "doctor") echo "selected = 'selected'"; ?>>Doctor</option>
		</select>
		<br>
		<br>
		<input type="text" name="nombre" placeholder="Nombre" value="<?php echo $nombre;?>" required>
		<br>
		<br>
		<input type="text" name="apellido" placeholder="Apellido" value="<?php echo $apellido;?>" required>
		<br>
		<br>
		<input type="text" name="telefono" placeholder="Telefono" value="<?php echo $telefono;?>" required>
		<br>
		<br>
		<select name="tipo_telefono" required>
			<option value="celular" <?php if($tipo_telefono == "Celular") echo "selected = 'selected'";?>>Celular</option>
			<option value="casa" <?php if($tipo_telefono == "Casa") echo "selected = 'selected'";?>>Casa</option>
			<option value="trabajo" <?php if($tipo_telefono == "Trabajo") echo "selected = 'selected'";?>>Trabajo</option>
			<option value="otro" <?php if($tipo_telefono == "Otro") echo "selected = 'selected'";?>>Otro</option>
		</select>
		<br>
		<br>
		<input type="email" name="correo" placeholder="Correo Electronico" value="<?php echo $correo;?>">
		<br>
		<br>
		<input type="text" name="direccion" placeholder="Direccion" value="<?php echo $direccion;?>">
		<input type="submit" name="registrar" value="Modificar">
			<input type="submit" name="mostrar" value="mostrar" onclick="contactos1.php">
		</form>

	</center>

	<script type="text/javascript">
		

		var form = document.getElementsById("form");

		var nombre = document.getElementById("nombre");
		var apellido = document.getElementById("apellido");
		var telefono = document.getElementById("telefono");

		var errorNom = document.getElementById("errorNom");
		var errorApe = document.getElementById("errorApe");
		var errorTel = document.getElementById("errorTel");

		
		/*function validar()
		{
			alert("hola");

			if(!(nombre.value == NaN)
			{
				errorNom.innerHTML = "Ingrese un nombre correcto";
			}

			//document.write("holq");

			//form.submit();
		}*/

		

	</script>

</body>
</html>
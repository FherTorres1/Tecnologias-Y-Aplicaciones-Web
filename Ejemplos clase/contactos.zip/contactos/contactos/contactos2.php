<?php 
		//print_r("hola guarde");
	if(isset($_POST["guardar"]))
	{
		///print_r("hola");

		$servidor = 'localhost';
		$usuario = 'root';
		$pass = '';
		$bd = 'contactos';

		$con = new mysqli($servidor, $usuario, $pass, $bd);

		if ($con->connect_errno) 
		{
			echo "Error al conectarse {$con->connect_errno}";
			die();
		}

		$titulo = $_POST["titulo"];
		$nombre = $_POST["nombre"];
		$apellido = $_POST["apellido"];
		$telefono = $_POST["telefono"];
		$tipoTel = $_POST["tipoTel"];
		$correo = $_POST["correo"];
		$direccion = $_POST["direccion"];

		$query = "insert into informacion (titulo,nombre,apellido,telefono,tipoTel,correo,direccion) values ('$titulo','$nombre','$apellido','$telefono','$tipoTel','$correo','$direccion')";

		$resultados = $con->query($query);


	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>CONTACTOS FORMULARIO</title>
</head>
<style type="text/css">
	
	.form
	{
		font-family: Arial;
		font-size: 1em;

	}

</style>
<body>

	<center>
		<form method="POST" class="form" id="form">
			<label>CONTACTO</label>
			<br><br><br>
			<label>Titulo:</label>
			<select name="titulo" id="titulo">
				<option value="lincenciatura">Lincenciatura</option>
				<option value="maestria">Maestria</option>
				<option value="doctorado">Doctorado</option>
				<option value="bachillerato">Bachillerato</option>
				<option value="otro">Otro</option>
			</select>
			<br><br>
			<label>Nombre: </label>
			<input type="text" name="nombre" required="true" id="nombre">
			<br>
			<label id="errorNom" style="color: red"></label>
			<br>
			<label>Apellido: </label>
			<input type="text" name="apellido" required="true" id="apellido">
			<br>
			<label id="errorApe" style="color: red"></label>
			<br>
			<label>Telefono: </label>
			<input type="text" name="telefono" required="true" id="telefono">
			<br>
			<label id="errorTel" style="color: red"></label>
			<br>
			<label>Tipo de telefono: </label>
			<select name="tipoTel" id="tipoTel">
				<option value="movil">Movil</option>
				<option value="casa">Casa</option>
				<option value="oficina">Oficina</option>
				<option value="local">Local</option>
				<option value="otro">Otro</option>
			</select>
			<br><br>
			<label>Correo: </label>
			<input type="email" name="correo" id="correo">
			<br><br>
			<label>Dirección: </label>
			<input type="text" name="direccion" id="direccion">
			<br>
			<br>
			<br>
			<input type="submit" name="guardar" value="Guardar">
			<input type="submit" name="mostrar" value="mostrar" onclick="contactos1.php">
		</form>

	</center>

	<script type="text/javascript">
		

		var form = document.getElementsById("form");

		var nombre = document.getElementById("nombre");
		var apellido = document.getElementById("apellido");
		var telefono = document.getElementById("telefono");

		var errorNom = document.getElementById("errorNom");
		var errorApe = document.getElementById("errorApe");
		var errorTel = document.getElementById("errorTel");

		
		/*function validar()
		{
			alert("hola");

			if(!(nombre.value == NaN)
			{
				errorNom.innerHTML = "Ingrese un nombre correcto";
			}

			//document.write("holq");

			//form.submit();
		}*/

		

	</script>

</body>
</html>
<?php 

	$id_contacto = $_GET['id'];

	$servidor = 'localhost';
	$usuario = 'root';
	$pass = '';
	$bd = 'contactos';

	$con = new mysqli($servidor, $usuario, $pass, $bd);

	$query = "DELETE FROM informacion where id_contacto = '$id_contacto'";
	$resultado = mysqli_query($con,$query);

	if ($con->connect_errno) 
	{
		echo "Error al conectarse {$con->connect_errno}";
		die();
	}
	else
	{
		header('Location:contactos1.php');
	}	

?>


<?php 
	$servidor = 'localhost';
	$usuario = 'root';
	$pass = '';
	$bd = 'contactos';

	$con = new mysqli($servidor, $usuario, $pass, $bd);

	if ($con->connect_errno) 
	{
		echo "Error al conectarse {$con->connect_errno}";
		die();
	}

?>

<!DOCTYPE html>
<html>
<head>
	<title>CONTACTOS</title>
</head>
<body>

	<center>
		<form method="POST">
			
		<label>CONTACTOS</label>
		<br>
		<br>
		<a href="contactos2.php">Registrar</a>
		<br><br>
		<table>
			
			<tr>
				<th> Titulo </th>
				<th> Nombre </th>
				<th> Apellido </th>
				<th> Telefono </th>
				<th> Tipo Tel </th>
				<th> Correo </th>
				<th> Direccion </th>
			</tr>



			<?php


				$query = "select * from informacion";
				$resultados = mysqli_query($con,$query);

				while ($row = mysqli_fetch_array($resultados)) 
				{	
					//$id_contacto = $row[0];
					$id_contacto = $row[0];
					$titulo = $row[1];
					$nombre = $row[2];
					$apellido = $row[3];
					$telefono = $row[4];
					$tipoTel = $row[5];
					$correo = $row[6];
					$direccion = $row[7];

					echo "<tr>";
					echo "<td>".$titulo."</td>";
					echo "<td>".$nombre."</td>";
					echo "<td>".$apellido."</td>";
					echo "<td>".$telefono."</td>";
					echo "<td>".$tipoTel."</td>";
					echo "<td>".$correo."</td>";
					echo "<td>".$direccion."</td>";
					echo "<td> <a href='eliminar.php?id=$id_contacto'>Eliminar</a> </td>";
					echo "<td> <a href='editar.php?id=$id_contacto'>Editar</a> </td>";
					echo "</tr>";
				}	

			?>

		</table>

		</form>
		
	</center>
	
</body>
</html>
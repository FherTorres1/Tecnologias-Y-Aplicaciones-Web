<footer class="main-footer">
    <strong>Copyright &copy; 2014-2018. Fher Torres.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Tecnologias y Aplicaciones Web</b>
    </div>
 </footer>
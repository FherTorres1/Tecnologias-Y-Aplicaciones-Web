<?php
session_destroy();
echo"<script>
		window.location = 'index.php?action=login';
	</script>";

?>

<h1>¡Haz salido de la aplicación!</h1>
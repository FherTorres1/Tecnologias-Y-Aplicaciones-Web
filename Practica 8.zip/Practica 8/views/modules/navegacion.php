<nav>
<ul>
	<li><a href='index.php?action=inicio'>Inicio</a></li>
	<li><a href='index.php?action=alumnos'>Alumnos</a></li>
	<li><a href='index.php?action=maestros'>Maestros</a></li>
	<li><a href='index.php?action=carreras'>Carreras</a></li>
</ul>
</nav>
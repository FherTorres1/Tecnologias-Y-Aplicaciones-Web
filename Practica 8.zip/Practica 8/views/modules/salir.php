<?php
session_destroy();
header("location:index.php?action=inicio");

?>

<h1>¡Haz salido de la aplicación!</h1>